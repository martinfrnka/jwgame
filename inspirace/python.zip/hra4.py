import pygame
import pygame.locals
import sys
import random

winWidth = 1024
winHeight = 768
bgColor = (0, 0, 10)
playerWidth = 60
playerHeight = 20

posx=winWidth/2 - playerWidth/2
posy=winHeight - 20 - playerHeight-200

moveleft = False
moveright = False

speedx = 8.0

gamestate = "playing"

fallSpeed = 3.0
thingEventInterval = 350
thingCnt = 3

itemSize = 20

class Player():
    def __init__(self, posx, posy, speedx, windowWidth):
        self.surface = pygame.image.load('truck_mini.png').convert_alpha()
        self.posX = posx
        self.posY = posy
        self.playerWidth = self.surface.get_width()
        self.playerHeight = self.surface.get_height()
        self.speedX = speedx
        self.moveleft = False
        self.moveright = False
        self.maxRight = windowWidth - self.playerWidth
        self.reverse = False
    
    def update(self):
        if self.moveleft:
            self.posX = self.posX - self.speedX
        if self.posX < 0:
            self.moveleft = False
            self.posX = 0

        if self.moveright:
            self.posX = self.posX + self.speedX
        if self.posX > self.maxRight:
            self.moveright = False
            self.posX = self.maxRight
    
    def getRect(self):
        return pygame.Rect(self.posX, self.posY, self.playerWidth, self.playerHeight)

    def clear(self, surface, bgColor):
        pygame.draw.rect(surface, bgColor, self.getRect())

    def draw(self, surface):
        if self.reverse:
            surface.blit(pygame.transform.flip(self.surface, True, False), (self.posX, self.posY))
        else:
            surface.blit(self.surface, (self.posX, self.posY))
        

class Score():
    def __init__(self):
        self.posx = 10
        self.posy = 10
        self.points = 0
        self.pismo = pygame.font.SysFont("comicsansms", 30)
        self.text = self.pismo.render(str(self.points), True, (200, 200, 200))
    
    def addPoints(self, howMuch = 1):
        self.points += howMuch
        self.text = self.pismo.render(str(self.points), True, (200, 200, 200))

    def clear(self, surface, bgColor):
        pygame.draw.rect(surface, bgColor, (self.posx, self.posy, self.text.get_width(), self.text.get_height()))

    def draw(self, surface):
        surface.blit(self.text, (self.posx, self.posy))


class Item():
    def __init__(self):
        if random.randint(0, 10) > 2:
            self.isFood = True
        else:
            self.isFood = False
        
        if self.isFood:
            self.surface = pygame.image.load('apple_small.png').convert_alpha()
        else:
            self.surface = pygame.image.load('pendovert.png').convert_alpha()
        self.sizex = self.surface.get_width()
        self.sizey = self.surface.get_height()

        self.posx = random.randint(0, winWidth - self.sizex)

        self.posy = -self.sizey

        self.fallSpeed = random.random()/2.0 + fallSpeed
        self.alive = True


    def clear(self, surface, bgColor):
        pygame.draw.rect(surface, bgColor, self.getRect())

    def draw(self, surface):
        surface.blit(self.surface, (self.posx, self.posy))

    def getRect(self):
        return pygame.Rect(self.posx, self.posy, self.sizex, self.sizey)
    
    def update(self):
        if self.alive:
            self.posy = self.posy + self.fallSpeed
        if self.posy > winHeight:
            self.alive = False
    
    def collision(self, rectangle):
        status = 0
        if (self.posy + self.sizey >= rectangle.top) and (self.posy < rectangle.bottom):
            if (self.posx + self.sizex >= rectangle.left) and (self.posx <= rectangle.right):
                if self.alive and self.isFood:
                    status = 1
                elif self.alive and not self.isFood:
                    status = -1
                self.alive = False
                
        return status
        
def startScreen():
    pass
    
def playing():
    pass

def gameOver():
    pass


pygame.init()
window = pygame.display.set_mode((winWidth,winHeight), pygame.FULLSCREEN)
pygame.draw.rect(window, bgColor, (0,0, winWidth, winHeight))
pygame.mouse.set_visible(False)

clock = pygame.time.Clock()
fnt = pygame.font.SysFont("comicsansms", 12)

veci = []
body = Score()
hrac = Player(posx, posy, speedx, winWidth)

NEWTHINGEVENT, milisecs, trail = pygame.USEREVENT+1, thingEventInterval, [] 

pygame.time.set_timer(NEWTHINGEVENT, milisecs)

while True:

    if gamestate == "start":
        startScreen()
    elif gamestate == "playing":
        playing()
    else:
        gameOver()

    # prochazime vsechny udalosti
    for evt in pygame.event.get():
        # nastala udalost konec?
        if evt.type == pygame.QUIT:
            sys.exit(0)
        if  evt.type == NEWTHINGEVENT:
            for i in range(0,thingCnt):
                veci.append(Item())

        
        #nastala udalost stisknuti klavesy?
        if evt.type == pygame.KEYDOWN:
            if evt.key == pygame.K_ESCAPE:
                sys.exit(0)
            if evt.key == pygame.K_LEFT:
                hrac.moveleft = True
                hrac.reverse = True
            if evt.key == pygame.K_RIGHT:
                hrac.moveright = True
                hrac.reverse = False

        if evt.type == pygame.KEYUP:
            if evt.key == pygame.K_LEFT:
                hrac.moveleft = False
            if evt.key == pygame.K_RIGHT:
                hrac.moveright = False

    statistics = fnt.render("Pocet objektu: " + str(len(veci)), True, (200, 200, 200))

    #smazat body a statistiku
    body.clear(window, bgColor)
    pygame.draw.rect(window, bgColor, (10,100, statistics.get_width(), statistics.get_height()))

    # smazat hrace
    #pygame.draw.rect(window,(0, 0, 0), hrac.getRect())
    hrac.clear(window, bgColor)

    # posuneme hrace
    hrac.update()

    # Smazat a posunout objeky

    for vec in veci:
        vec.clear(window, bgColor)
        vec.update()

    # jdeme kreslit hrace
    hrac.draw(window)
    
    for vec in veci:
        kolize = vec.collision(hrac.getRect())
        if not vec.alive:
            veci.remove(vec)
        if kolize == 1:    
            body.addPoints(10)
        elif kolize == -1:
            body.addPoints(-100)
        else:
            vec.draw(window)

    body.draw(window)
    window.blit(statistics, (10, 100))

    clock.tick(100)
    
    pygame.display.flip()

