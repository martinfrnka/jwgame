import pygame
import pygame.locals
import sys

pygame.init()

window = pygame.display.set_mode((600,400))

while True:
    for evt in pygame.event.get():
        if evt.type == pygame.QUIT or evt.type == pygame.KEYDOWN:
          sys.exit(0)  

    pygame.draw.rect(window,(58, 173, 43),(0,0,200,400))
    pygame.draw.rect(window,(255, 255, 255),(200,0,200,400))
    pygame.draw.rect(window,(175, 1, 1),(400,0,200,400))

    pygame.draw.ellipse(window,(61, 0, 59),(0,0,600,400))

    pygame.draw.circle(window,(188, 162, 30),(300,200),100,10)
    pygame.draw.circle(window,(0, 26, 160),(300,200),80,10)
    pygame.draw.circle(window,(175, 91, 22),(300,200),60,10)
    pygame.draw.aaline(window,(0,0,225), (0,0), (600,400), 1)
    pygame.display.update()


  
