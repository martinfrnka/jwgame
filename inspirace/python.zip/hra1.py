import pygame
import pygame.locals
import sys

winWidth = 1024
winHeight = 768

playerWidth = 60
playerHeight = 20

posx=winWidth/2 - playerWidth/2
posy=winHeight - 20 - playerHeight

moveleft = False
moveright = False

speedx = 0.8

pygame.init()

window = pygame.display.set_mode((winWidth,winHeight), pygame.FULLSCREEN)
pygame.mouse.set_visible(False)

while True:
    # prochazime vsechny udalosti
    for evt in pygame.event.get():
        # nastala udalost konec?
        if evt.type == pygame.QUIT:
            sys.exit(0)  
        
        #nastala udalost stisknuti klavesy?
        if evt.type == pygame.KEYDOWN:
            if evt.key == pygame.K_ESCAPE:
                sys.exit(0)
            if evt.key == pygame.K_LEFT:
                moveleft = True
            if evt.key == pygame.K_RIGHT:
                moveright = True

        if evt.type == pygame.KEYUP:
            if evt.key == pygame.K_LEFT:
                moveleft = False
            if evt.key == pygame.K_RIGHT:
                moveright = False


    # smazat hrace
    pygame.draw.rect(window,(0, 0, 0),(posx,posy,playerWidth,playerHeight))


    # posuneme hrace
    if moveleft:
        posx = posx - speedx
        if posx < 0:
            moveleft = False

    if moveright:
        posx = posx + speedx
        if posx > winWidth - playerWidth:
            moveright = False


    # jdeme kreslit hrace
    pygame.draw.rect(window,(175, 1, 1),(posx,posy,playerWidth,playerHeight))
    pygame.display.update()

